
package rectangleareagui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RectangleAreaGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Tính Diện Tích Hình Chữ Nhật");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(4, 2));

        JLabel label1 = new JLabel("Nhập chiều dài:");
        JTextField text1 = new JTextField();
        JLabel label2 = new JLabel("Nhập chiều rộng:");
        JTextField text2 = new JTextField();
        JButton calculateButton = new JButton("Tính diện tích");
        JLabel resultLabel = new JLabel("Diện tích:");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double length = Double.parseDouble(text1.getText());
                    double width = Double.parseDouble(text2.getText());
                    double area = length * width;
                    resultLabel.setText("Diện tích: " + area);
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Vui lòng nhập số hợp lệ!");
                }
            }
        });

        frame.add(label1);
        frame.add(text1);
        frame.add(label2);
        frame.add(text2);
        frame.add(calculateButton);
        frame.add(resultLabel);

        frame.setVisible(true);
    }
}

