
package phepnhan;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

public class Phepnhan {
    

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
          
        // 1. Thực hiện phép cộng hai số
        System.out.print("Nhập số thứ nhất: ");
        int a = scanner.nextInt();
        System.out.print("Nhập số thứ hai: ");
        int b = scanner.nextInt();
        System.out.println("Tổng: " + (a * b));
        JFrame frame = new JFrame("Phép nhân hai số");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        
        JLabel label1 = new JLabel("Nhập số thứ nhất:");
        label1.setBounds(20, 20, 120, 25);
        frame.add(label1);
        
        JTextField text1 = new JTextField();
        text1.setBounds(150, 20, 100, 25);
        frame.add(text1);
        
        JLabel label2 = new JLabel("Nhập số thứ hai:");
        label2.setBounds(20, 60, 120, 25);
        frame.add(label2);
        
        JTextField text2 = new JTextField();
        text2.setBounds(150, 60, 100, 25);
        frame.add(text2);
        
        JButton button = new JButton("Tính tích");
        button.setBounds(90, 100, 100, 25);
        frame.add(button);
        
        JLabel result = new JLabel("Kết quả: ");
        result.setBounds(20, 140, 200, 25);
        frame.add(result);
        
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int num1 = Integer.parseInt(text1.getText());
                    int num2 = Integer.parseInt(text2.getText());
                    result.setText("Kết quả: " + (num1 * num2));
                } catch (NumberFormatException ex) {
                    result.setText("Vui lòng nhập số hợp lệ!");
                }
            }
        });
        
        frame.setVisible(true);
                
       
    }
    
}
